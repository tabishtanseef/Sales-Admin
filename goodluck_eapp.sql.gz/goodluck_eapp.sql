-- MySQL dump 10.13  Distrib 5.6.44, for Linux (x86_64)
--
-- Host: localhost    Database: goodluck_eapp
-- ------------------------------------------------------
-- Server version	5.6.44-cll-lve

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `book_details`
--

DROP TABLE IF EXISTS `book_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `book_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_title` varchar(100) NOT NULL,
  `book_code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=83 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `book_details`
--

LOCK TABLES `book_details` WRITE;
/*!40000 ALTER TABLE `book_details` DISABLE KEYS */;
INSERT INTO `book_details` (`id`, `book_title`, `book_code`) VALUES (1,'New School Maths - 1','OOC552'),(2,'New School Maths - 2','1O13DO'),(3,'New School Maths - 3','KD17O7'),(4,'New School Maths - 4','D9OUC5'),(5,'New School Maths - 5','L8K50D'),(6,'New School Maths - 6','L50C5O'),(7,'New School Maths - 7','O395UK'),(8,'New School Maths - 8','DO567K'),(9,'Innovative Biology - 6','135U4C'),(10,'Innovative Biology - 7','4K613U'),(11,'Innovative Biology - 8','GOL097'),(12,'Lets Talk - 1','095GK8'),(13,'Lets Talk - 2','36K554'),(14,'Lets Talk - 3','065KUC'),(15,'Lets Talk - 4','05LOC9'),(16,'Lets Talk - 5','45C3L0'),(17,'Aura - 1','03OU85'),(18,'Aura - 2','611K6O'),(19,'Basic English Grammar - 1','ODCL41'),(20,'Basic English Grammar - 2','56KO00'),(21,'Basic English Grammar - 3','4L80C1'),(22,'Basic English Grammar - 4','48K56C'),(23,'Basic English Grammar - 5','208515'),(24,'Basic English Grammar - 6','8O11OK'),(25,'Basic English Grammar - 7','0CL0G1'),(26,'Basic English Grammar - 8','50O190'),(27,'Bhasha Kalash - 1','1OC551'),(28,'Bhasha Kalash - 2','4701UC'),(29,'Bhasha Kalash - 3','O5LU17'),(30,'Bhasha Kalash - 4','5161C7'),(31,'Bhasha Kalash - 5','56OOU2'),(32,'Bhasha Kalash - 6','1DC560'),(33,'Bhasha Kalash - 7','1L5O0K'),(34,'Bhasha Kalash - 8','6570L1'),(35,'Bhasha Mani - 1','0OL0K3'),(36,'Bhasha Mani - 2','4C105K'),(37,'Bhasha Mani - 3','322U45'),(38,'Bhasha Mani - 4','O92L1K'),(39,'Bhasha Mani - 5','0DO014'),(40,'Bhasha Mani - 6','G3K11O'),(41,'Bhasha Mani - 7','8C3OL5'),(42,'Bhasha Mani - 8','LO541O'),(43,'Bhasha Path - 1','0L5O98'),(44,'Bhasha Path - 2','6ODKG7'),(45,'Bhasha Path - 3','L01GC7'),(46,'Bhasha Path - 4','OK8UC1'),(47,'Bhasha Path - 5','8LCGOD'),(48,'Bhasha Path - 6','L7C3D0'),(49,'Bhasha Path - 7','5O067D'),(50,'Bhasha Path - 8','O16UOG'),(51,'Chandan - 1','CK1G11'),(52,'Chandan - 2','31C0UL'),(53,'Chandan - 3','G1U176'),(54,'Chandan - 4','0O855G'),(55,'Chandan - 5','GK72O0'),(56,'Chandan - 6','KU4O71'),(57,'Chandan - 7','O7K0LG'),(58,'Chandan - 8','GC4960'),(59,'Conquer English - 1','2U61D2'),(60,'Conquer English - 2','01O552'),(61,'Conquer English - 3','60048L'),(62,'Conquer English - 4','45041K'),(63,'Conquer English - 5','515O0O'),(64,'Conquer English - 6','CGO56D'),(65,'Conquer English - 7','2LG502'),(66,'Conquer English - 8','0OC0L7'),(67,'Easy Computer - 1','1510O5'),(68,'Easy Computer - 2','713C3D'),(69,'Easy Computer - 3','35KOOU'),(70,'Easy Computer - 4','U60C55'),(71,'Easy Computer - 5','O2L9K0'),(72,'Easy Computer - 6','KOUD15'),(73,'Easy Computer - 7','161O5L '),(74,'Easy Computer - 8','KO106G'),(75,'Kavya - 1','17OG60'),(76,'Kavya - 2','C6U61K'),(77,'Kavya - 3','4O1570'),(78,'Kavya - 4','41K3LD'),(79,'Kavya - 5','G4010U'),(80,'Kavya - 6','OU070K'),(81,'Kavya - 7','C4757D'),(82,'Kavya - 8','5802C1');
/*!40000 ALTER TABLE `book_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodluck_app`
--

DROP TABLE IF EXISTS `goodluck_app`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goodluck_app` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `num` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodluck_app`
--

LOCK TABLES `goodluck_app` WRITE;
/*!40000 ALTER TABLE `goodluck_app` DISABLE KEYS */;
INSERT INTO `goodluck_app` (`id`, `name`, `password`, `email`, `num`) VALUES (1,'tabish','1234','tabish@gmail.com','12345678'),(18,'yusha','1234','yushayusha44@gmail.com','9978901'),(17,'arman','1234','arman@gmail.com','9898765412'),(16,'tan','1234','tan@gmail.com','1234'),(15,'pp','1234','P@gmail.com','1234'),(14,'taab','1234','tab@gmail.com','1234'),(13,'sisi','1234','si@gmail.com','1234'),(12,'hihi','1234','gi@gmail.com','122344'),(11,'demo','1234','demo@gmail.com','14741'),(19,'g','1234','g@gmail.com','19rh'),(20,'yusha','000786','yusha gour@gmail.com','886505548'),(21,'k','1234','k@gmail.com','2234'),(22,'billi','1234','billu@gmail.com','3568'),(40,'PULIKANDLA SHANKAR ','6300792275','shankarpuli86@gmail.com','6300792275'),(28,'he','1234','he@gmail.com','1234'),(25,'gjvn','ghv','bill','fhhj'),(29,'Gourav Jain','1234','gouravjain@gmail.com','9876543210'),(30,'tar','1234','tar@gmail.com','1234'),(31,'shobit123','1234','shobit@gmail.com','9897142536'),(32,'shah','123456','md@gmail.com','9758304881'),(33,'meenu','mishri12','meenu.goodluck01@gmail.com','8266909789'),(34,'lalain','12345678','aclalalain@gmail.com','9294764887'),(35,'Avinash Pal','7739502613','narayanpalbgp112@gmail.com','7739502613'),(36,'kavitha','nkdiniya','kavithayercaud@gmail.com','9894789354'),(37,'Raj saju','345678910','guddasahu@emali','9993058190'),(38,'Veenal','veenalb2353','gagannag60@gmail.com','8349035379'),(39,'shah','1234','shah@gmail.com','1234567896');
/*!40000 ALTER TABLE `goodluck_app` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `goodluck_app_user_book`
--

DROP TABLE IF EXISTS `goodluck_app_user_book`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `goodluck_app_user_book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `book_code` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `goodluck_app_user_book`
--

LOCK TABLES `goodluck_app_user_book` WRITE;
/*!40000 ALTER TABLE `goodluck_app_user_book` DISABLE KEYS */;
INSERT INTO `goodluck_app_user_book` (`id`, `user_id`, `book_code`) VALUES (30,1,'4O1570'),(29,1,'C6U61K'),(28,1,'17OG60'),(27,32,'36K554'),(26,32,'095GK8'),(25,15,'36K554'),(24,15,'095GK8'),(23,15,'1O13DO'),(22,15,'OOC552'),(21,15,'KD17O7');
/*!40000 ALTER TABLE `goodluck_app_user_book` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'goodluck_eapp'
--

--
-- Dumping routines for database 'goodluck_eapp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-01-08  5:58:37
