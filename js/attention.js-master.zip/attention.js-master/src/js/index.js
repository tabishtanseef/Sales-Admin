import { Alert } from './alert';
import { Prompt } from './prompt';
import { Confirm } from './confirm';

const version = '0.1.0';

export { Alert,Prompt,Confirm,version };
